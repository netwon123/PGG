package treecmp.io;

public enum OutputFileType {
    txt, csf, xlsx, pdf;
}
