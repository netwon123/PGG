// ClassDistribution.java
//
// (c) 1999-2004 PAL Development Core Team
//
// This package may be distributed under the
// terms of the Lesser GNU General Public License (LGPL)

package pal.substmodel;

/**
 * <p>Title: ClassDistribution </p>
 * @author Matthew Goode
 */
import pal.misc.*;
import pal.math.*;
import pal.datatype.*;
import java.io.*;

public interface ClassDistribution {

}